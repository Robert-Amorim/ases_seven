export { default as Notifications } from "./Notifications";
export { default as MyCourses } from "./MyCourses";
export { default as MyDepartments } from "./MyDepartments";
export { default as MyChurch } from "./MyChurch"; // Renomeie o componente para MyChurchBlock se for o caso
export { default as Highlights } from "./Highlights";
export { default as Calendar } from "./Calendar";
export { default as Links } from "./Links";
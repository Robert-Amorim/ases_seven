import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="bg-blue-900 text-white py-4 px-6 shadow-md flex justify-between items-center sticky top-0 z-50">
      <h1 className="text-2xl font-bold">ASES7</h1>
      <nav className="space-x-4 hidden md:block">
        <Link to="/" className="hover:underline uppercase">Início</Link>
        <Link to="/departamentos" className="hover:underline uppercase">Departamentos</Link>
        <Link to="/minha-igreja" className="hover:underline uppercase">Minha Igreja</Link>
        <a href="#" className="hover:underline uppercase">Cursos</a>
        <a href="#" className="hover:underline uppercase">Perfil</a>
      </nav>
    </header>
  );
}

export default function Footer() {
  return (
    <footer className="bg-blue-900 text-white py-4 text-center mt-6">
      <p className="text-sm">Plataforma ASES7 • Associação Sul Espírito Santense © 2025</p>
    </footer>
  );
}

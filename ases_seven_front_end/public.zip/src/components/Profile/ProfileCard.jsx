export default function ProfileCard({ nome, igreja, membroDesde, avatar, email, telefone }) {
  return (
    <div className="bg-white rounded-2xl shadow p-6 flex flex-col items-center gap-3">
      <img
        src={avatar || "https://ui-avatars.com/api/?name=User&background=0D8ABC&color=fff"}
        alt={nome}
        className="w-20 h-20 rounded-full object-cover shadow"
      />
      <h2 className="text-xl font-bold text-blue-900">{nome}</h2>
      <p className="text-sm text-slate-700">Membro desde: {membroDesde}</p>
      <p className="text-sm text-blue-800 font-semibold">Igreja: {igreja}</p>
      <div className="flex flex-col items-center gap-1 mt-2">
        <span className="text-sm text-slate-600">Email: {email}</span>
        <span className="text-sm text-slate-600">Telefone: {telefone}</span>
      </div>
      <button className="mt-4 px-4 py-1 bg-blue-700 hover:bg-blue-800 text-white rounded shadow text-sm">
        Editar Perfil
      </button>
    </div>
  );
}

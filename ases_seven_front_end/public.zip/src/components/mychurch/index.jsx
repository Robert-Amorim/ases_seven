// MyChurch components
export { default as ChurchCard } from "./ChurchCard";
export { default as DistrictHighlights } from "./DistrictHighlights";
export { default as SpacePastors } from "./SpacePastors";
export { default as DistrictGoals } from "./DistrictGoals"; // Renomeie o componente para MyChurch se for o caso
export { default as TalkPastor } from "./TalkPastor"; // Renomeie o componente para MyChurch se for o caso
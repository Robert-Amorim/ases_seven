export {default as MyChurch} from "./MyChurch";
export {default as Departments} from "./Departments";
export {default as Home} from "./Home";
export {default as Profile} from "./Profile";
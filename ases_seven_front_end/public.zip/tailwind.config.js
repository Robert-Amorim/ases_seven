/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Adicione cores personalizadas aqui se quiser
        // primary: '#1e40af',
      },
      fontFamily: {
        // Exemplo: font sans customizada
        // sans: ['Inter', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
